#!/bin/sh
#md5不能有6太难了.....
#开启网络端口5555
iptables -A INPUT -p tcp --dport  5555 -j ACCEPT
#开启adb端口5555
setprop service.adb.tcp.port 5555
stop adbd
start adbd